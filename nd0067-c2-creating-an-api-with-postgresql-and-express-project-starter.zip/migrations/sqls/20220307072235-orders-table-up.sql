CREATE TABLE orders (
    id SERIAL PRIMARY KEY,
    status VARCHAR(65),
    user_id BIGINT REFERENCES users(id) ON DELETE CASCADE
);